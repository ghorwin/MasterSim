/* --------------------------------------------------------------
 * Copyright (c) 2013, AIT Austrian Institute of Technology GmbH.
 * All rights reserved. See file FMIPP_LICENSE for details.
 * --------------------------------------------------------------*/

/// \file IPCLogger.cpp

#include "export/include/IPCLogger.h"


IPCLogger::~IPCLogger() {}
