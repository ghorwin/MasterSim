// IBK Library - Collection of classes, functions and algorithms
//               for development of numeric simulations
//
// Copyright (C) 2007 Andreas Nicolai, Andreas.Nicolai@gmx.net
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

#include "IBK_configuration.h"

#ifdef __BORLANDC__
  #include "IBK_prehead.h"
  #pragma hdrstop
#else
#endif

#include <windows.h>
#include <iphlpapi.h>

#include "IBK_hardware.h"
#include "IBK_StringUtils.h"

namespace IBK {

std::vector<std::string> getMacAddress() {
	std::vector<std::string> result;
	char data[4096];
    ZeroMemory( data, 4096 );
	unsigned long  len = 4000;
	PIP_ADAPTER_INFO pinfo = ( PIP_ADAPTER_INFO ) data;

    DWORD ret = GetAdaptersInfo( pinfo, &len );
    if( ret != ERROR_SUCCESS )
		return result;

	while ( pinfo ) {
		if( pinfo->Type == MIB_IF_TYPE_ETHERNET )  {// ignore software loopbacks and other strange things that might be present
			std::stringstream str;
			const int count = pinfo->AddressLength;
			for(int k = 0; k < count - 1; k++ ) {
				int val = static_cast<int>(pinfo->Address[k]);
				str << std::hex << std::setfill ('0') << std::setw (2) << val << "-";
			}
			int val = static_cast<int>(pinfo->Address[count - 1]);
			str << std::hex << std::setfill ('0') << std::setw (2) << val;
			result.push_back(str.str());
		}
		pinfo = pinfo->Next;
	}

	return result;
}

#ifdef __BORLANDC__
#pragma option push -w-
bool has_cpuid()
{
    __asm
    {
		PUSHFD
		POP EAX
		MOV EDX, EAX
		XOR EAX, 0x00200000
		PUSH EAX
		POPFD
		PUSHFD
		POP EAX
		XOR EAX, EDX
        SHR EAX, 21
    }
}

void get_cpuid(sCpuId* CpuID)
{
	__asm
	{
		PUSH EBX
		PUSH EDI
		MOV EDI, EAX
		MOV EAX,1
		DW 0xA20F
		STOSD
		MOV EAX, EBX
		STOSD
		MOV EAX, ECX
		STOSD
		MOV EAX, EDX
		STOSD
		POP EDI
		POP EBX
	}
}
#pragma option pop
#else
void get_cpuid(unsigned int info, unsigned int *eax, unsigned int *ebx, unsigned int *ecx, unsigned int *edx)
{
  *eax = info;
  asm volatile(
    "mov %%ebx, %%edi;" /* 32bit PIC: don't clobber ebx */
    "cpuid;"
    "mov %%ebx, %%esi;"
    "mov %%edi, %%ebx;"
    :"+a" (*eax), "=S" (*ebx), "=c" (*ecx), "=d" (*edx)
    : :"edi");
}
#endif

sCpuId getCPUId() {
	sCpuId cpu_id = {0};
#ifdef __BORLANDC__
    if( has_cpuid() )
		get_cpuid(&cpu_id);
#else
    get_cpuid(0, &cpu_id.ulVersion, &cpu_id.ulOther, &cpu_id.ulExtendedFeatures, &cpu_id.ulFeatures);
#endif
    return cpu_id;
}

#ifdef __BORLANDC__
typedef char TVendor[12];
void GetCPUVendor(TVendor* vendor)
{
	__asm
	{
		PUSH EBX // Save affected register
		PUSH EDI
		MOV EDI,EAX // vendor
		MOV EAX,0
		DW 0xA20F // CPUID Command
		MOV EAX,EBX
		STOSD
		MOV EAX,EDX
		STOSD
		MOV EAX,ECX
		STOSD
		POP EDI // Restore registers
		POP EBX
	}
}

std::string getCPUString() {
	TVendor result = {0};
	GetCPUVendor(&result);
	return std::string(result);
}
#else
#endif

} // namespace IBK
