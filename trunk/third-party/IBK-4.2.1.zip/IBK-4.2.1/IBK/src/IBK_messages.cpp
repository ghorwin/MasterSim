#include "IBK_configuration.h"

#include <fstream>
#include <sstream>
#include <iostream>

#include "IBK_messages.h"
#include "IBK_StringUtils.h"
#include "IBK_FormatString.h"

#if defined (IBK_ENABLE_COLORED_CONSOLE) && (defined(_MSC_VER) || defined(__BORLANDC__) || defined(__MINGW32__))
  #include <windows.h>
  #include <cstdio>
#endif

namespace IBK {

/// All terminal codes used for ANSI color writing.
extern const char * const TERMINAL_CODES[16];

void set_console_text_color(ConsoleColor c) {
#ifdef IBK_ENABLE_COLORED_CONSOLE

#if (defined(_MSC_VER) || defined(__BORLANDC__) || defined(__MINGW32__))
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);  // Get handle to standard output
	SetConsoleTextAttribute(hConsole,static_cast<WORD>(c));
#else
	// terminal codes > 16 are bold fonts and must be mapped accordingly
	int i = static_cast<int>(c);
	if (i>=16)
		i = i >> 1; // also set bold flag?
	std::cerr << TERMINAL_CODES[i];
	std::cout << TERMINAL_CODES[i];
#endif

#else // IBK_ENABLE_COLORED_CONSOLE
	(void)c;
#endif // IBK_ENABLE_COLORED_CONSOLE
}

extern const char * const TERMINAL_CODES[16] =
{
	"\033[22;30m", // black			CF_BLACK
	"\033[22;34m", // blue 			CF_BLUE
	"\033[22;32m", // green 		CF_GREEN
	"\033[22;36m", // cyan 			CF_CYAN
	"\033[22;31m", // red			CF_RED
	"\033[22;35m", // magenta		CF_MAGENTA
	"\033[22;33m", // brown			CF_YELLOW
	"\033[22;37m", // gray			CF_GREY
	"\033[01;30m", // dark gray 	CF_DARK_GREY
	"\033[01;34m", // light blue	CF_BRIGHT_BLUE
	"\033[01;32m", // light green	CF_BRIGHT_GREEN
	"\033[01;36m", // light cyan	CF_BRIGHT_CYAN
	"\033[01;31m", // light red		CF_BRIGHT_RED
	"\033[01;35m", // light magenta	CF_BRIGHT_MAGENTA
	"\033[01;33m", // yellow		CF_BRIGHT_YELLOW
	"\033[01;37m"  // white			CF_WHITE
};


}  // namespace IBK

