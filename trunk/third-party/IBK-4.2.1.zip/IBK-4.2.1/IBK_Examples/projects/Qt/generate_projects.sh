#!/bin/bash

for filename in ../../src/*.cpp ; do
	CPPFILE=$(basename "$filename")
	PROJECTNAME="${CPPFILE%.*}"
	PROJECTFILE="$PROJECTNAME.pro"
	if [ -e $PROJECTFILE ]
	then
		echo "... skipping $PROJECTFILE (project exists already)"
	else
		echo "*** generating $PROJECTFILE ***"
		cat >$PROJECTFILE <<EOL
# Project file for ${PROJECTNAME}
# remember to set DYLD_FALLBACK_LIBRARY_PATH on MacOSX
TEMPLATE = app
TARGET = ${PROJECTNAME}

QT       -= gui core

CONFIG   += console
CONFIG   -= app_bundle

CONFIG(debug, debug|release) {
	OBJECTS_DIR = debug
	DESTDIR = ../../../bin/debug
}
else {
	OBJECTS_DIR = release
	DESTDIR = ../../../bin/release
}

INCLUDEPATH += \
	../../../IBK/src \

LIBS += -L../../../lib -lIBK

SOURCES += \
		../../src/${CPPFILE}

EOL

	fi
done

