// Example for the use of the IBK Library class 'StopWatch'.
#include <iostream>
#include <sstream>
#include <cstdlib> // for EXIT_SUCCESS

#include <IBK_StopWatch.h>
#include <IBK_math.h>

void some_lengthy_function();
void flops_counter();

int main() {

	// we can create a stop watch object and the counter starts to run immediately
	IBK::StopWatch global;
	// now we can have local watches, too
	for (int j=0; j<10; ++j) {
		IBK::StopWatch w;
		some_lengthy_function();
		// now let's output the time spent so far, the strings should be 8 characters long
		std::cout << "global: " << global.diff_str(8) << "  local: " << w.diff_str(8) << std::endl;
	}
	// we can stop a stop watch
	global.stop();
	std::cout << '\n' << "Total time elapsed: " << global.diff_str() << std::endl;
	// and we can restart it again
	global.start();
	some_lengthy_function();
	std::cout << "Time for one function call in milli seconds: " << global.difference() << std::endl;


	// demonstrate interval timer function

	// set interval size
	global.setIntervalLength(2); // in secons
	global.start();
	for (int j=0; j<200; ++j) {
		some_lengthy_function();
		if (global.intervalCompleted())
			std::cout << "Interval completed at " << global.diff_str() << " after " << j << " cycles." << std::endl;
	}
	std::cout << "Loop completed at " << global.diff_str() << std::endl;

	// finally a MFlops counter based on StopWatch
	flops_counter();


#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

// here we do something terrible slow and stupid
void some_lengthy_function() {
	std::string dummy;
	double x=0;
	for (int i=0; i<10000; ++i) {
		x += 1.0;
		std::stringstream lstrm;
		lstrm << 100*IBK::f_exp(x/1000.0)*IBK::f_sqrt(x) << std::endl;
		dummy = dummy + lstrm.str()[0];
	};
	dummy.clear();
	std::cout << dummy;
	std::cout.flush();
}


void flops_counter() {
	const long long N = 100000;
	IBK::StopWatch watch;
	double a = 1;
	long long cycles = 0;
	unsigned int loops=0;
	while (true) {
		for (int i=0; i<N; ++i) {
			a += 0.1;
			a *= 1.01;
			a -= 0.1;
			a /= 1.01;
		}
		++cycles;
		double diff_sec = watch.difference()*1e-3;
		if (diff_sec > 1) {
			long long total_ops = N*cycles*4;
			double MFlops = total_ops*1e-6/diff_sec;
			std::cout << total_ops << " floating point ops in " << diff_sec << " s  (" << MFlops << " Mflops), a = " << a << std::endl;
			if (++loops > 10)
				break;
			watch.start();
			cycles = 0;
			a /= N;
		}
	}
}
