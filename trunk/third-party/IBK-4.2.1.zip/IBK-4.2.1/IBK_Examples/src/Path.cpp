#include <iostream>
#include <fstream>
#include <cstdlib>

#include <IBK_Path.h>
#include <IBK_assert.h>

#ifdef _WIN32

#include <Windows.h>
#include <Shlobj.h>

IBK::Path userDirectory() {

	IBK::Path result;

	// SHGetSpecialFolderLocation generates a PIDL. The memory for the PIDL
	// is allocated by the shell, and should be freed using the shell
	// mallocator COM object. Use SHGetMalloc to retrieve the malloc object
	LPMALLOC pShellMalloc;
	if(FAILED(SHGetMalloc(&pShellMalloc)))
		return result;

	// if we were able to get the shell malloc object, then
	// proceed by fetching the pidl
	LPITEMIDLIST  pidl;
	HRESULT hdres = SHGetSpecialFolderLocation(NULL, CSIDL_APPDATA, &pidl);
	if(hdres == S_OK) {
		// return is true if success
		wchar_t szDir[MAX_PATH] = {0};
		SHGetPathFromIDListW(pidl, szDir);
		pShellMalloc->Free(pidl);
		try {
			result = IBK::WstringToUTF8(szDir);
		}
		catch(...) {
			// result string keeps empty
		}
	}
	pShellMalloc->Release();
	return result;
}
#endif

int main() {

	bool gotException = false;

	try {

		// ** constructors **

		// empty path
		IBK::Path p;
		IBK_ASSERT(!p.isValid());
		IBK_ASSERT(p.str() == "");

		// from c-string
		IBK_ASSERT( IBK::Path("./blub.txt") == "blub.txt");
		IBK_ASSERT( IBK::Path("blub.txt") == "blub.txt" );
		IBK_ASSERT( IBK::Path("../blub.txt") == "../blub.txt");
		IBK_ASSERT( IBK::Path("c:\\blubb\\file.txt") == "C:/blubb/file.txt");
		IBK_ASSERT( IBK::Path("C:\\blubb\\bla\\blub") == "C:/blubb/bla/blub" );
		IBK_ASSERT( IBK::Path("C:\\") == "C:" );
		IBK_ASSERT( IBK::Path("/") == "/" );
		IBK_ASSERT( IBK::Path("./") == "." );
		IBK_ASSERT( IBK::Path("../") == ".." );
		IBK_ASSERT( IBK::Path("/..") == "/.." );

		// from std::string - utf8-encoded
		std::string relPathString("../../blubb/file.txt");
		IBK::Path pTwo(relPathString);

		// swap
		p.swap(pTwo);
		IBK_ASSERT( p == "../../blubb/file.txt" );

		// clear
		p.clear();
		IBK_ASSERT( p == "");
		IBK_ASSERT( !p.isValid());

		// returning strings
		p = IBK::Path("../../blubb/file.txt"); // assignment operator
		std::string pathStr = p.str();
		IBK_ASSERT(pathStr == "../../blubb/file.txt");
	#ifdef _WIN32
		std::wstring pathWStr = p.wstr(); // only _WIN32
		std::wstring testString1 = IBK::UTF8ToWstring("../../blubb/file.txt");
		IBK_ASSERT(pathWStr == testString1);

		std::string oSString = p.osStr();
		IBK_ASSERT(oSString == "..\\..\\blubb\\file.txt");

		IBK::Path pThree("C:\\Program Files (x86)\\IBK");
		IBK_ASSERT( pThree.drive() == "C:");
		std::string absoluteOSPathString = pThree.absolutePath().osStr();
		IBK_ASSERT( absoluteOSPathString == "C:\\Program Files (x86)\\IBK");
	#endif // _WIN32

		p = IBK::Path("/home/myfiles/data/datfile.txt");
		bool success;
		IBK::Path relPath = p.relativePath(IBK::Path("/home/myfiles/oldstuff"), &success);
		IBK_ASSERT(success);
		IBK_ASSERT(relPath == "../data/datfile.txt" );
		IBK_ASSERT(p.relativePath(IBK::Path("/home"), &success) == "myfiles/data/datfile.txt" );
		IBK_ASSERT(p.relativePath(IBK::Path("/home/myfiles/data"), &success) == "datfile.txt" );
		IBK_ASSERT(p.relativePath(IBK::Path("D:\\bla"), &success) == "" );


		/// \todo add some test about absolute path - behaviour of current and setCurrent must be discussed
		/// \todo define illegal path behavior for windows and linux
		gotException = false;
#ifdef _WIN32
		gotException = !IBK::Path::setCurrent(IBK::Path("C:/Users"));
		IBK_ASSERT( IBK::Path::current() == IBK::Path("C:/Users") );
		gotException = !IBK::Path::setCurrent(IBK::Path("/tmp"));
#else
		gotException = !IBK::Path::setCurrent(IBK::Path("/tmp"));
		IBK_ASSERT( IBK::Path::current() == IBK::Path("/tmp") );
		gotException = !IBK::Path::setCurrent(IBK::Path("D:/test"));
#endif
		IBK_ASSERT( gotException == true );

		IBK_ASSERT( IBK::Path("D:/test").drive() == "D:");
		IBK_ASSERT( IBK::Path("c:/test").drive() == "C:");
		IBK_ASSERT( IBK::Path("../test").drive() == "");
		IBK_ASSERT( IBK::Path("/test").drive() == "");

		gotException = false;
		try {
			IBK::Path("").parentPath();
		} catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == std::string("Invalid path: ''") )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );
		IBK_ASSERT( IBK::Path("./blub.txt").parentPath() == ".");
		IBK_ASSERT( IBK::Path("blub.txt").parentPath() == ".");
		IBK_ASSERT( IBK::Path("../blub.txt").parentPath() == "..");
		IBK_ASSERT( IBK::Path("C:\\blubb\\bla\\blub").parentPath() == "C:/blubb/bla");

		gotException = false;
		try {
			IBK::Path("C:").parentPath();
		} catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == "No parent possible." )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );

		IBK_ASSERT( IBK::Path("").isValid() == false);
		IBK_ASSERT( IBK::Path("./blub.txt").isValid() == true);

#ifdef _WIN32
		/// \todo implement test
		IBK_ASSERT( IBK::Path("/tmp").isDirectory() == false);
		IBK_ASSERT( IBK::Path("/tmp").exists() == false);
		IBK_ASSERT( IBK::Path("C:/Users").isDirectory() == true);
		IBK_ASSERT( IBK::Path("C:/Users").exists() == true);
#else
		/// \todo what about links?
		IBK_ASSERT( IBK::Path("/etc/resolv.conf").isFile() == true);
		IBK_ASSERT( IBK::Path("/tmp").isDirectory() == true);
		IBK_ASSERT( IBK::Path("/tmp").exists() == true);
		IBK_ASSERT( IBK::Path("c:/tmp").isDirectory() == false);
		IBK_ASSERT( IBK::Path("c:/tmp").exists() == false);
#endif

		IBK_ASSERT( IBK::Path("/tmp").isAbsolute() == true);
		IBK_ASSERT( IBK::Path("c:/isAbsolute").isAbsolute() == true);
		IBK_ASSERT( IBK::Path("../tmp").isAbsolute() == false);
		IBK_ASSERT( IBK::Path("./tmp").isAbsolute() == false);

		gotException = false;
		try {
			IBK::Path("").filename();
		} catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == "Invalid path: ''" )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );

		IBK_ASSERT( IBK::Path("./blub.txt").filename() == "blub.txt");
		IBK_ASSERT( IBK::Path("blub.txt").filename() == "blub.txt");
		IBK_ASSERT( IBK::Path("../blub.txt").filename() == "blub.txt");
		IBK_ASSERT( IBK::Path("C:\\blubb\\bla\\blub").filename() == "blub");
		IBK_ASSERT( IBK::Path("C:").filename() == "");

		IBK_ASSERT( IBK::Path("../blub.txt").extension() == "txt");
		IBK_ASSERT( IBK::Path("../archive.tar.gz").extension() == "gz");
		IBK_ASSERT( IBK::Path("../README").extension() == "");

		/// \todo where blub.txt is a folder, how do we know we have a folder here
//		IBK_ASSERT( IBK::Path("../blub.txt").extension() == "");
		IBK_ASSERT( IBK::Path("..").extension() == "");
		IBK_ASSERT( IBK::Path(".").extension() == "");

		IBK_ASSERT( IBK::Path("../blub.txt").withoutExtension() == "../blub");
		IBK_ASSERT( IBK::Path("C:\\blubb\\bla\\blub").withoutExtension() == "C:/blubb/bla/blub");
		IBK_ASSERT( IBK::Path("./archive.tar.gz").withoutExtension() == "archive.tar");

		IBK::Path p1("../bla");
		IBK::Path p2,p3,p4,p5,p6;
		p2 = p3 = p4 = p5 = p6 = p1;
		p1.addPath( IBK::Path("blubb/blo.txt") );
		p2.addPath( IBK::Path("") );
		p3.addPath( IBK::Path("/") );
		p4.addPath( IBK::Path("./") );
		p5.addPath( IBK::Path("/blub") );
		p6.addPath( IBK::Path("C:\\blub") );
		IBK_ASSERT( p1 == "../bla/blubb/blo.txt");
		IBK_ASSERT( p2 == "../bla");
		IBK_ASSERT( p3 == "../bla");
		IBK_ASSERT( p4 == "../bla");
		IBK_ASSERT( p5 == "../bla/blub");
		/// \todo  -> manual Win32 check
		IBK_ASSERT( p6 == "../bla/C:/blub");
		IBK::Path p7("../bla.txt");
		p7.addPath( IBK::Path("blub") );
		IBK_ASSERT( p7 == "../bla.txt/blub");

		IBK::Path p8("blub");
		IBK::Path p9,p10,p11,p12,p13;
		p9 = p10 = p11 = p12 = p13 = p8;
		p8.addExtension("txt");
		p9.addExtension(".txt");
		p10.addExtension("");
		p11.addExtension(".");
		p12.addExtension(" ");
		p13.addExtension(".long.extension");
		IBK_ASSERT( p8 == "blub.txt");
		IBK_ASSERT( p9 == "blub.txt");
		IBK_ASSERT( p10 == "blub");
		IBK_ASSERT( p11 == "blub");
		IBK_ASSERT( p12 == "blub");
		IBK_ASSERT( p13 == "blub.long.extension");

		IBK::Path p14("blub.bla");
		p14.addExtension("txt");
		IBK_ASSERT( p14 == "blub.bla.txt");

		IBK_ASSERT( IBK::Path("${XXX}/blub").hasPlaceholder() == true );
		IBK_ASSERT( IBK::Path("blub").hasPlaceholder() == false );

		IBK_ASSERT( IBK::Path("${XXX}/blub").placeholderString() == "XXX" );
		IBK_ASSERT( IBK::Path("blub").placeholderString() == "" );

		/// \todo create error cases
		IBK::Path path("${my path}/fname.txt");
		std::map<std::string,IBK::Path> placeholders;
		placeholders["my path"] = "C:\\data";
		IBK_ASSERT( path.withReplacedPlaceholders(placeholders) == IBK::Path("C:/data/fname.txt") );

		/// \todo create error cases
		IBK::Path fnameWithPlaceholder( "${User Data Dir}/Materials/mat_01.mat" );
		IBK::Path relativeFname;
		std::string placeholderName;
		success = fnameWithPlaceholder.extractPlaceholder(placeholderName, relativeFname);
		IBK_ASSERT( success == true );
		IBK_ASSERT( relativeFname == IBK::Path("Materials/mat_01.mat") );
		IBK_ASSERT( placeholderName == "User Data Dir" );

		/// \todo create error cases
		IBK::Path placeholderPath("/home/user/data");
		placeholderName = "User Data";
		IBK::Path fullPath("/home/user/data/myfiles/datafile.txt");
		success = fullPath.insertPlaceholder(placeholderName, placeholderPath);
		IBK_ASSERT( success == true );
		IBK_ASSERT( fullPath == IBK::Path("${User Data}/myfiles/datafile.txt") );

		/// \todo check consistency of drive definition
		IBK_ASSERT( IBK::Path("d:/test1/temp").branchCount() == 3);
		IBK_ASSERT( IBK::Path("d:/").branchCount() == 1);
		IBK_ASSERT( IBK::Path("/").branchCount() == 1);
		IBK_ASSERT( IBK::Path("/temp").branchCount() == 2);


		IBK_ASSERT( IBK::Path("d:/programs/IBK/Delphin/Delphin5/Climate_DB").subBranch(1, 3) == IBK::Path("programs/IBK/Delphin") );
		IBK_ASSERT( IBK::Path("d:/programs/IBK/Delphin/Delphin5/Climate_DB").subBranch(0, 3) == IBK::Path("d:/programs/IBK") );
		IBK_ASSERT( IBK::Path("/home/stvo/test").subBranch(0,0) == IBK::Path("/home/stvo/test") );
		IBK_ASSERT( IBK::Path("/home/stvo/test").subBranch(0,1) == IBK::Path("/") );
		IBK::Path pSub("/home/stvo/test");
		gotException = false;
		try {
			pSub.subBranch(0,6);
		} catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == "Insufficient branches for given count." )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );
		gotException = false;
		try {
			pSub.subBranch(6,0);
		} catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == "Illegal index for branch start." )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );
		gotException = false;
		try {
			pSub = IBK::Path("");
			pSub.subBranch(0,1);
		}
		catch ( IBK::Exception & ex ){
			if ( std::string(ex.what()) == "Invalid path: ''" )
				gotException = true;
		}
		IBK_ASSERT( gotException == true );
		gotException = false;



		IBK::Path fname0( "/home/stvo/ibk/src/../Materials/mat_01.mat" );
		IBK::Path fname1("../Materials/mat_01.mat");
		IBK::Path fname2("/../Materials/mat_01.mat");
		IBK::Path fname3("./../Materials/");
		fname0.removeRelativeParts();
		fname1.removeRelativeParts();
		fname2.removeRelativeParts();
		fname3.removeRelativeParts();
		IBK_ASSERT( fname0 == "/home/stvo/ibk/Materials/mat_01.mat");
		IBK_ASSERT( fname1 == "../Materials/mat_01.mat");
		IBK_ASSERT( fname3 == "../Materials");
//		IBK_ASSERT( fname2 == "/../Materials/mat_01.mat"); // how do we handle illeagal path?


		/// \todo review this interface -> either static routine or member without parameter not both
		/// how does this work when setCurrent fails
#ifdef _WIN32

		IBK::Path userPath = userDirectory();
		IBK::Path rootPath = userPath / IBK::Path("tmp/Delphin/Delphin6/Climate_DB");
		if ( IBK::Path::makePath( rootPath ) && IBK::Path::setCurrent( rootPath ) ){

			IBK_ASSERT( IBK::Path::isRootPath(userPath / IBK::Path("tmp/Delphin")) == true );
			IBK_ASSERT( IBK::Path::isRootPath(userPath / IBK::Path("tmp/lib/")) == false );

			int64_t fileSize = IBK::Path("c:/Windows/notepad.exe").fileSize();
			if ( fileSize == -1 ) {
				IBK_ASSERT_X( false, "File doesn't exist.");
			}

			// 'blubbs' is a directory -> "cp blubb.txt blubbs" -> "/tmp/blubbs/blubb.txt"
			std::string testFile = (userPath / "tmp/test.txt").str();
			std::ofstream testFileStr(testFile.c_str());
			testFileStr << "Test";
			testFileStr.close();
			if ( !IBK::Path::copy( IBK::Path(testFile), userPath / IBK::Path("/tmp/Delphin") ) ){
				IBK_ASSERT_X( false, "Copy file to directory failed." );
			}

//			const IBK::Path& filename,
//			int hour,
//			int minute,
//			int second,
//			int day,
//			int month,
//			int year
			IBK::Path filePath = userPath / IBK::Path("/tmp/Delphin/test.txt");
			std::time_t originalTime = filePath.lastWriteTime();
			bool res = IBK::Path::setFileTime( filePath, 23, 11, 33, 1, 5, 2014 );
			IBK_ASSERT( res );

			std::time_t modifyTime = filePath.lastWriteTime();
			IBK_ASSERT( modifyTime != originalTime );

			std::time_t writeTime = filePath.fileTime();
			IBK_ASSERT( writeTime != originalTime );

			if ( !IBK::Path::copy(	filePath,
									userPath / IBK::Path("/tmp/Delphin/test2.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			if ( !IBK::Path::copy(	filePath,
									userPath / IBK::Path("/tmp/Delphin/Delphin6/test3.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// override
			if ( !IBK::Path::copy(	filePath,
									userPath / IBK::Path("/tmp/Delphin/Delphin6/test3.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// must fail recursive example
			if ( IBK::Path::copy(	userPath / IBK::Path("/tmp/Delphin/"),
									userPath / IBK::Path("/tmp/Delphin/Delphin6/Climate_DB") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// must fail recursive example
			if ( IBK::Path::copy(	userPath / IBK::Path("/tmp/Delphin/"),
									userPath / IBK::Path("/tmp/Delphin/test.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file must fail. Otherwise it's an error." );
			}


			if ( !IBK::Path::move(	userPath / IBK::Path("/tmp/Delphin/test.txt"),
									userPath / IBK::Path("/tmp/Delphin/test2.txt") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			if ( !IBK::Path::copy(	userPath / IBK::Path("/TestOrdner"),
									userPath / IBK::Path("/tmp/Delphin1") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			if ( !IBK::Path::move(	userPath / IBK::Path("/tmp/Delphin1"),
									userPath / IBK::Path("/tmp/Delphin/Delphin6") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}


			if ( !IBK::Path::move(	userPath / IBK::Path("/tmp/Delphin/test2.txt"),
									userPath / IBK::Path("/tmp/Delphin/Delphin6") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			// same directory, must fail -> to be conform with move UNIX
			if ( IBK::Path::move(	userPath / IBK::Path("/tmp/Delphin/Delphin6"),
									userPath / IBK::Path("/tmp/Delphin/") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			/// \todo test case when subfolder is target (recursive copy)

//			// 'blubbs' and 'blah' are a directories, blubb exists -> "/tmp/blah/blubbs"
//			IBK::Path::move("/tmp/blubbs", "/tmp/blah");

//			// 'blubbs' is a directory, 'blubb.txt' must also be a directory, otherwise function returns false
//			IBK::Path::move("/tmp/blubbs", "/tmp/blubb.txt");

			if ( ! IBK::Path::remove( userPath / IBK::Path("/tmp/Delphin") ) ){
				IBK_ASSERT( false );
			}
		}
#else
		IBK::Path rootPath("/tmp/Delphin/Delphin6/Climate_DB");
		if ( IBK::Path::makePath( rootPath ) && IBK::Path::setCurrent( rootPath ) ){

			IBK_ASSERT( IBK::Path::isRootPath(IBK::Path("/tmp/Delphin")) == true );
			IBK_ASSERT( IBK::Path::isRootPath(IBK::Path("/tmp/lib/")) == false );

			int64_t fileSize = IBK::Path("/etc/resolv.conf").fileSize();
			if ( fileSize == -1 ) {
				IBK_ASSERT_X( false, "File doesn't exist.");
			}

			// 'blubbs' is a directory -> "cp blubb.txt blubbs" -> "/tmp/blubbs/blubb.txt"
			if ( !IBK::Path::copy( IBK::Path("/etc/resolv.conf"), IBK::Path("/tmp/Delphin") ) ){
				IBK_ASSERT_X( false, "Copy file to directory failed." );
			}

//			const IBK::Path& filename,
//			int hour,
//			int minute,
//			int second,
//			int day,
//			int month,
//			int year
			IBK::Path::setFileTime( IBK::Path("/tmp/Delphin/resolv.conf"), 23, 11, 33, 1, 5, 2014 );

			std::time_t modifyTime = IBK::Path("/tmp/Delphin/resolv.conf").lastWriteTime();
			IBK_ASSERT( modifyTime == 1398978693 );

			std::time_t writeTime = IBK::Path("/tmp/Delphin/resolv.conf").fileTime();
			IBK_ASSERT( writeTime == 1398978693 );

			if ( !IBK::Path::copy(	IBK::Path("/tmp/Delphin/resolv.conf"),
									IBK::Path("/tmp/Delphin/resolv.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			if ( !IBK::Path::copy(	IBK::Path("/tmp/Delphin/resolv.conf"),
									IBK::Path("/tmp/Delphin/Delphin6/resolv.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// override
			if ( !IBK::Path::copy(	IBK::Path("/tmp/Delphin/resolv.conf"),
									IBK::Path("/tmp/Delphin/Delphin6/resolv.txt") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// must fail recursive example
			if ( IBK::Path::copy(	IBK::Path("/tmp/Delphin/"),
									IBK::Path("/tmp/Delphin/Delphin6/Climate_DB") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}

			// must fail recursive example
			if ( IBK::Path::copy(	IBK::Path("/tmp/Delphin/"),
									IBK::Path("/tmp/Delphin/resolv.conf") ) )
			{
				IBK_ASSERT_X( false, "Copy file must fail. Otherwise it's an error." );
			}


			if ( !IBK::Path::move(	IBK::Path("/tmp/Delphin/resolv.conf"),
									IBK::Path("/tmp/Delphin/resolv.txt") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			// 'blubbs' is a directory -> "mv blubb.txt blubbs" -> "/tmp/blubbs/blubb.txt"
			if ( !IBK::Path::copy(	IBK::Path("/tmp/Delphin/"), IBK::Path("/tmp/Delphin1") ) )
			{
				IBK_ASSERT_X( false, "Copy file failed." );
			}
			if ( !IBK::Path::move(	IBK::Path("/tmp/Delphin1"), IBK::Path("/tmp/Delphin.Delphin6") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}


			if ( !IBK::Path::move(	IBK::Path("/tmp/Delphin/resolv.txt"), IBK::Path("/tmp/Delphin/Delphin6") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			// same directory, must fail -> to be conform with move UNIX
			if ( IBK::Path::move(	IBK::Path("/tmp/Delphin/Delphin6"), IBK::Path("/tmp/Delphin/") ) )
			{
				IBK_ASSERT_X( false, "Move file failed." );
			}

			/// \todo test case when subfolder is target (recursive copy)

//			// 'blubbs' and 'blah' are a directories, blubb exists -> "/tmp/blah/blubbs"
//			IBK::Path::move("/tmp/blubbs", "/tmp/blah");

//			// 'blubbs' is a directory, 'blubb.txt' must also be a directory, otherwise function returns false
//			IBK::Path::move("/tmp/blubbs", "/tmp/blubb.txt");

			if ( ! IBK::Path::remove( IBK::Path("/tmp/Delphin") ) ){
				IBK_ASSERT( false );
			}
		}
#endif



	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
