// Example for the use of the IBK Library output functions
#include <iostream>
#include <iterator>
#include <cstdlib> // for EXIT_SUCCESS
#include <IBK_matrix.h>
#include <IBK_InputOutput.h>
using namespace std;
using namespace IBK;

int main() {
	// creates a vector with 6 initial elements and initial value of 5
	vector<double> v(6, 5.0);

	// write this vector to an output stream, using 1.12 as data string for the first column
	write_vector(cout, "1.12", v);
	cout << "\n\n";

	// adjust the stream format
	cout.precision(3);
	cout << scientific;

	// write the vector again
	write_vector(cout, "1.12", v);
	cout << "\n\n";

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

#if 0

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <stdexcept>
#include <ctime>
#include <algorithm>
#include <cstdlib> // for EXIT_SUCCESS

#include <IBK_StringUtils.h>
#include <IBK_InputOutput.h>
#include <IBK_StopWatch.h>
#include <IBK_FileReader.h>

using namespace IBK;

template<typename CONT>
void writeList(const std::string& file, const CONT& cont) {
	std::ofstream out(file.c_str());
	for( typename CONT::const_iterator it=cont.begin(); it!=cont.end(); ++it) {
		out << *it << "\n";
	}
}

int main() {
	IBK::Path testFile("D:/Programming/libs/IBK/trunk/bin/temperature_field.out");


	// read file with
	double t1(0.0);
	double t2(0.0);
	IBK::StopWatch watch;
	std::vector<std::string> lastLineTokens;
	std::list<std::string> content1;
	std::vector<std::string> content2;
	const unsigned int NUMBER = 10;
	for( unsigned int i=0; i<NUMBER; ++i) {
		content1.clear();
		watch.start();
		std::ifstream in(testFile.str().c_str(), std::ios::binary);
		IBK::read_string_list_binary(in, lastLineTokens, content1);
		t1 += watch.difference();
		in.close();

		watch.start();
		FileReader reader1(testFile, 32768);
		//reader1.toStrings(content2);
		t2 += watch.difference();
	}
	std::cout << "read_string_list_binary: " << t1 / NUMBER << std::endl;
	std::cout << "BinaryFileReader: " << t2 / NUMBER << std::endl;

	//	std::cout << "read_string_list_binary: " << watch.diff_str() << std::endl;
	writeList("read_string_list_binary.txt", content1);
	writeList("BinaryFileReader.txt", content2);

//	watch.start();
//	std::vector<std::string> content3;
//	reader.toStrings2(content3);
//	std::cout << "BinaryFileReader: " << watch.diff_str() << std::endl;
//	writeList("BinaryFileReader2.txt", content3);

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

#endif

