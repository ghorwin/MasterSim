#include <iostream>
#include <string>
#include <fstream>

#include <IBK_ArgParser.h>

int main(int argc, char * argv[]) {
	IBK::ArgParser args;

	// add some flags and options

	// a flag that only exists as short version
	args.addFlag('i', "", "Create invisible output.");
	// a flag that only exists as long version
	args.addFlag(0, "all-results", "Always write all results.\nThis is a long description which spans several lines and also contains a line break character.");
	// a flag that only exists as long version but has no documentation
	args.addFlag('b', "build", "");

	args.addOption('o', "output-file", "Some output file to write output to.", "FILENAME", "");

	if (argc > 1) {
		args.parse(argc, argv);

		args.handleDefaultFlags(std::cout);

	}
	else {

		const char * const testArgs[] = {"-i", "--all-results", "-o=blö blü.txt"};
		int testArgCount = sizeof(testArgs)/sizeof(char*);

		args.parse(testArgCount, testArgs);

		args.handleDefaultFlags(std::cout);
	}
	if (args.hasOption('o')) {
		std::ofstream out(args.option('o').c_str());
		out << "done" << std::endl;
	}

	return 0;
}
