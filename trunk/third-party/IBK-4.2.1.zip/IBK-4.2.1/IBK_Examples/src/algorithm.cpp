#include <IBK_algorithm.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <map>
#include <cstdlib> // for EXIT_SUCCESS
using namespace std;
using IBK::copy_if;

int main() {
	// Often it is required to copy only a certain kind of values from
	// one container to another. Although the STL provides the algorithm
	// remove_copy and remove_copy_if, the algorithm copy_if is missing
	const double data[] = { -2, -5, 1, 15, -2, 5, -.5, 0, .4 };
	std::vector<double> c1(data, data + sizeof(data)/sizeof(double) );

	std::cout << "Original vector:" << std::endl;
	std::copy(c1.begin(), c1.end(), ostream_iterator<double>(cout, "  ") );
	std::cout << std::endl;

	// now we want to copy all elements that whose value is less then 0
	// into another container
	std::vector<double> c2;

	IBK::copy_if(c1.begin(), c1.end(), back_inserter(c2),
		std::bind2nd( std::less<double>(), 0) );
	// the binary predicate 'less' returns true, when 'value < 0'
	// bind2nd is used to bind the 0 as the second parameter

	std::cout << "Copy of vector with only negative elements:" << std::endl;
	std::copy(c2.begin(), c2.end(), ostream_iterator<double>(cout, "  ") );
	std::cout << std::endl;

	std::cout << "\nCreating a map of vectors and searching for values" << std::endl;
	std::map<unsigned int, double > testMap;

	testMap[15] = 12.5;
	testMap[25] = 15.5;

	// search map for an element with known key
	// this is short for
	// if (testMap.find(15) != testMap.end())
	std::cout << "Key 15: " << (IBK::map_contains(testMap, 15) ? "found" : "not in map") << std::endl;
	std::cout << "Key 20: " << (IBK::map_contains(testMap, 20) ? "found" : "not in map") << std::endl;

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

