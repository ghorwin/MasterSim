#include <string>
#include <iostream>
#include <stdexcept>
#include <cstdlib> // for EXIT_SUCCESS

#include <IBK_FormatString.h>
using namespace std;
using namespace IBK;

const char * const MSG_FUNCTION_ERROR_ID = "%1::%2::%3\n    ";
const char * const ERROR_MSG = "Error reading parameter '%1' for element %2!\n";
const char * const PERCENT_MSG = "You are recieving now %1%% of the data.\n";

// note, it is not possible (yet) to skip % characters in the format string

int main() {
	try {
		double d=3.1415;
		int i=3;
		// typical way to compose a message
		cout << FormatString("Printing number %1 within section %2.\n").arg(d).arg(i);

		// construction of the format_string step-by-step
		FormatString fstr;
		fstr.set(ERROR_MSG);  // here we set the message template
		fstr.arg("Value").arg(3);          // here we replace the % with actual values
		string result = "Result = " + fstr.str();
		cout << result;

		// construction on the fly, note the use of the member function str() to
		// convert a format string into a c++ string
		string msg = (FormatString(ERROR_MSG).arg("Value").arg(3)).str();
		cout << msg << endl;

		// or as one-liner
		cout << FormatString(ERROR_MSG).arg("Value").arg(3).str() << endl;

		// concatenation with other strings
		throw runtime_error("Here: " + FormatString(PERCENT_MSG).arg(5));
	}
	catch (std::exception& ex) {
		cerr << ex.what();
	}
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

