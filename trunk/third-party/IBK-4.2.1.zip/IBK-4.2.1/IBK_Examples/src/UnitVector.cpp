#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <cstdlib> // for EXIT_SUCCESS

#include <IBK_UnitVector.h>
#include <IBK_UnitList.h>
using namespace std;
using namespace IBK;

int main() {
	try {
		// Read vector data from string
		string test = "12.2 23.2 24.4 25.5 26.6 g";
		UnitVector testvector;
		testvector.read(test);

		// Data of the unit vector is stored in base SI unit
		cout << "Vector data in base SI unit = ";
		copy(testvector.m_data.begin(), testvector.m_data.end(), ostream_iterator<double>(cout, " "));
		cout << Unit(testvector.m_unit.base_id()) << endl;
		// Write vector in IO unit
		cout << "Vector data in IO unit      = " << testvector.toString() << endl;
	}
	catch (std::exception& ex) {
		cerr << ex.what() << endl;
	}
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

