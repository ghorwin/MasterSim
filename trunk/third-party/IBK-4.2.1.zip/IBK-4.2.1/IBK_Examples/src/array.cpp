// Example for the use of the IBK Library class template 'array'.
#include <iostream>
#include <algorithm>
#include <numeric>
#include <cstdlib> // for EXIT_SUCCESS
#include <IBK_array.h>
using IBK::array;
using namespace std;

const unsigned int N = 5;

int main() {
    // creates a C array of type double with 5 elements
    double arr1[N];

    // creates an IBK::array of type double with 5 elements
    array<double, N> arr2;
    // creates an IBK::array of type double with 5 elements and initial value of 2.0
    array<double, N> arr3(2.0);

    // the IBK::array has range checking
    try {
        arr2[N+3] = 5.0;  // throws an exeption
        arr1[N+3] = 5.0;  // would cause undefined behavior (program/system crash?)
    }
    catch (std::out_of_range& ex) {
        cerr << ex.what() << endl;
    }

    // the IBK::array does know its own size, the c-array does not
    cout << "Size of IBK::array = " << arr2.size() << endl;

    // fill the c-array with values
    for (unsigned int i=0; i<N; ++i)
        arr1[i] = 1.5;
    // calculate the sum of the c-array
    double sum=0.0;
    for (unsigned int i=0; i<N; ++i) 
        sum += arr1[i];
    cout << sum << endl;

    // you can use STL algorithms with the IBK::array
    fill(arr2.begin(), arr2.end(), 1.5);
    sum = accumulate(arr2.begin(), arr2.end(), 0.0);
    cout << sum << endl;

    // in general, use IBK::array instead of C arrays whenever you know the size
    // of the array at compile time.
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}
