#include <iostream>
#include <vector>
#include <cstdlib>

#include <IBK_StringUtils.h>
#include <IBK_assert.h>

bool matches_array(const std::vector<std::string> & tokens, const char * array[], unsigned int n) {
	std::vector<std::string> arrayVec(array, array+n);
	if (arrayVec.size() != tokens.size())
		return false;
	return std::equal(tokens.begin(), tokens.end(), arrayVec.begin());
}

int main() {

	try {

		// ** check for various explode syntaxes **

		std::vector<std::string> tokens;

		{
			IBK::explode("12,15,43", tokens, ",", IBK::EF_NoFlags);
			const char * result[] = {"12","15","43"};
			IBK_ASSERT( matches_array(tokens, result, sizeof(result)/sizeof(const char*)) );
		}

		{
			IBK::explode("12 , 15, 43 ", tokens, ",", IBK::EF_NoFlags);
			const char * result[] = {"12 "," 15"," 43 "};
			IBK_ASSERT( matches_array(tokens, result, sizeof(result)/sizeof(const char*)));
		}

		{
			IBK::explode("\n12 , 15,\t43 ", tokens, ",", IBK::EF_TrimTokens);
			const char * result[] = {"12","15","43"};
			IBK_ASSERT( matches_array(tokens, result, sizeof(result)/sizeof(const char*)));
		}

		{
			IBK::explode("12, ,43", tokens, ",", IBK::EF_NoFlags);
			const char * result[] = {"12"," ","43"};
			IBK_ASSERT( matches_array(tokens, result, sizeof(result)/sizeof(const char*)));
		}

		{
			IBK::explode("12 , ,43 ", tokens, ",", IBK::EF_TrimTokens | IBK::EF_KeepEmptyTokens);
			const char * result[] = {"12","", "43"};
			IBK_ASSERT( matches_array(tokens, result, sizeof(result)/sizeof(const char*)));
		}
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
