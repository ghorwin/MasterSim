#include <iostream>
#include <iomanip>
#include <algorithm>
#include <stdexcept>
#include <ctime>   // for time() in srand() and rand()
#include <cstdlib> // for EXIT_SUCCESS

#include <IBK_LinearSpline.h>
#include <IBK_StopWatch.h>

using namespace std;

void usageDemo();
void performanceTest();

int main() {
	try {
		cout << "*** Spline usage demo ***" << endl;
		usageDemo();

		cout << "\n*** Running performance test ***" << endl;
		performanceTest();
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
		return EXIT_FAILURE;
	}
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}


void usageDemo() {
	const unsigned int n = 20;
	// start random number generator
	srand(time(NULL));

	// create input data for spline or alternatively read input data
	// from file using the read() member function
	// the data points are stored in two vectors x and y
	vector<double> x,y;
	x.push_back(0.0);
	y.push_back(100.0/RAND_MAX*rand());
	for (unsigned int i=0; i<n; ++i) {
		double dx = 100.0/RAND_MAX*rand()/10.0;
		x.push_back( x.back() + dx );
		y.push_back(100.0/RAND_MAX*rand());
	}
	std::sort(y.begin(), y.end());

	// create a linear spline that contains input data vectors in m_x and m_y and also
	// the functionality to interpolate in these vectors.
	IBK::LinearSpline spl;
	// set the data in the spline
	// This can throw!
	try {
		spl.setValues(x, y);
	}
	catch (IBK::Exception & ex) {
		throw IBK::Exception(ex, "Error setting values.", "[usageDemo]");
	}

	// print our two vectors
	cout << fixed;
	cout.precision(1);
	cout << "Input data points:\n";
	cout << setw(10) << "x  " << setw(10) << "y" << endl;
	cout << string(25,'-') << endl;
	for (unsigned int i=0; i<n; ++i)
		cout << setw(10) << setprecision(1) << spl.x()[i]
			 << setw(10) << setprecision(3) << spl.y()[i] << endl;
	cout << endl;

	// interpolate between values
	cout << "Interpolated points:\n";
	cout << setw(10) << left << "x  " << setw(15) << left << "y  "
		 << setw(10) << left << "y (no interpolation)"<< endl;
	cout << string(45,'-') << endl;
	for (unsigned int i=0; i<10; ++i) {
		cout << setw(10) << setprecision(0) << i*10;
		// the member function value() interpolates between the values
		cout << setw(15) << setprecision(3) << spl.value(i*10);
		// the member function non_interpolated_value() returns the value
		// at the nearest x,y point with x < 10*i (used for hourly values without interpolation)
		cout << setw(15) << setprecision(3) << spl.nonInterpolatedValue(i*10) << endl;
	}
}


void generate(std::vector<double> & x,
			  std::vector<double> & y,
			  IBK::LinearSpline & spl,
			  std::vector<double> & x_samples)
{
	// spline size
	const unsigned int spline_size = 20000;
	// number of samples to interpolate
	const unsigned int n_samples = 100000;

	// start random number generator
	srand((unsigned int)time(NULL));

	// generate n sample points in the range of 100 to approximately 900
	// create input data for spline or alternatively read input data
	// from file using the read() member function
	// the data points are stored in two vectors x and y
	x.push_back(100.0);
	y.push_back(rand()/double(RAND_MAX)/spline_size);
	for (unsigned int i=0; i<spline_size; ++i) {
		double dx = 1e-10 + rand()/double(RAND_MAX)*1600.0/spline_size;
		x.push_back( x.back() + dx );
		y.push_back(rand()/double(RAND_MAX)/spline_size); // values between 0 and 100
	}
	//std::sort(y.begin(), y.end());
	cout << "Generated values between " << x.front() << " and " << x.back() << endl;

	// now generate n random numbers between 0 and approximately 1000
	for (unsigned int i=0; i<n_samples; ++i) {
		x_samples.push_back( rand()/double(RAND_MAX)*1000.0 );
	}

	try {
		spl.setValues(x, y);
		string errmsg;
		if (!spl.makeSpline(errmsg)) {
			throw std::runtime_error(errmsg);
		}
	}
	catch (std::exception & ex) {
		cerr << ex.what() << endl;
		exit(EXIT_FAILURE);
	}
}


double interpolate_lower_bound(	const std::vector<double> & x,
								const std::vector<double> & y,
								double xval)
{
	if (xval > x.back())
		return y.back();
	std::vector<double>::const_iterator it = std::lower_bound(x.begin(), x.end(), xval);
	if (it == x.begin())
		return y.front();
	unsigned int i = (unsigned int)std::distance(x.begin(), it) - 1;
	return y[i] + (y[i+1]-y[i])/(x[i+1]-x[i])*(xval-x[i]);
}


double calculate_lower_bound(const std::vector<double> & x,
							 const std::vector<double> & y,
							 const std::vector<double> & x_samples)
{
	// we use the std::lower_bound function to determine the correct x value
	double sum = 0;
	for (unsigned int i=0; i<x_samples.size(); ++i) {
		sum += interpolate_lower_bound(x, y, x_samples[i]);
	}
	return sum;
}


double calculate_value(const IBK::LinearSpline & spl,
					 const std::vector<double> & x_samples)
{
	double sum = 0;
	for (unsigned int i=0; i<x_samples.size(); ++i) {
		sum += spl.value(x_samples[i]);
	}
	return sum;
}


void performanceTest() {
	unsigned int iter_count = 1000;

	IBK::StopWatch watch;
	watch.start();
	std::vector<double> x;
	std::vector<double> y;
	IBK::LinearSpline spl;
	std::vector<double> x_samples;
	double sum;
	generate(x, y, spl, x_samples);
	cout << "generate()              = " << watch.diff_str() << endl;
	watch.stop();

	// first use std::lower_bound algorithm to search for interval and interpolate between values
	watch.start();

	for (unsigned int i=0; i<iter_count; ++i)
		sum = calculate_lower_bound(x, y, x_samples);
	cout << "calculate_lower_bound() = " << watch.diff_str() << " with " << sum << endl;
	watch.stop();

	// then use precalculated slopes
	watch.start();
	for (unsigned int i=0; i<iter_count; ++i)
		sum = calculate_value(spl, x_samples);
	cout << "calculate_value()       = " << watch.diff_str() << " with " << sum << endl;
}
