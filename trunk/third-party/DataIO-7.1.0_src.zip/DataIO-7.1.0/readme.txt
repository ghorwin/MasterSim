This library depends on the IBK library.

You need to place the IBK subdirectory from the IBK-library release
in this folder in order to compile the library.

For example: the release IBK-4.2.1.zip will contain the directory

IBK-4.2.1/IBK

which should be copied so that it is located besides DataIO and 
DataIO_Examples

DataIO-7.1.0/
  ...
  DataIO
  DataIO_Examples
  IBK
  ...


