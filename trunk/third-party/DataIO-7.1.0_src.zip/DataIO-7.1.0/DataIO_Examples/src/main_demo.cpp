#include <iostream>
#include <string>
#include <cstdlib>

#include <IBK_Exception.h>
#include <IBK_StopWatch.h>
#include <IBK_UnitList.h>
#include <IBK_crypt.h>
#include <IBK_StringUtils.h>

// include central header file for DataIO library.
#include <DataIO>

void copyDataIO(const IBK::Path & filename);
void createDataIO();
void createGeoFile();

int main(int argc, char * argv[]) {

	// either use own file path
	IBK::Path filename("../../data/L_ascii_DirectSimData/temperature_field.d6o"); // set filename

	// or file given via command line argument
	if (argc > 1)
		filename = argv[1];

	try {

		// First we demonstrate how to read and to write a DataIO container
		copyDataIO(filename);


	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}

	return EXIT_SUCCESS;
}



void copyDataIO(const IBK::Path & filename) {

	// create instance of DataIO container - empty and undefined at first
	DATAIO::DataIO dataFile;

	// To follow the progress when reading (large) files, a notification handler
	// can be used. The DataIO library provides one for console output.
	DATAIO::TextNotificationHandler notify;
	notify.m_process = "Reading... "; // this is the text printed as part of the progress bar

	// read file
	dataFile.read(filename, false, &notify);
	std::cout << std::endl;

	// read associated geometry file
	DATAIO::GeoFile geoFile;
	if (!dataFile.m_geoFileName.isValid()) {
		IBK::Path geoFilePath = filename.parentPath() / dataFile.m_geoFileName;
		notify.m_process = "Reading geometry... ";
		geoFile.read(geoFilePath, &notify);
		std::cout << std::endl;
	}

	// determine data format (updates dataformat member in DataIO container)
	dataFile.determineDataFormat(geoFile);

	// print some header information about the DataIO to be copied
	DATAIO::listDataIOHeader(dataFile, geoFile);

	// Convert all strings to value vectors, this needs to be done at least once before writing
	// the data to file, since otherwise part of the file may still be stored in unparsed strings.
	// This is due to the lazy evaluation concept of the DataIO library.
	// Here, we also print out the first value in each data set.

	std::cout << "\nFirst value for each time point..." << std::endl;
	std::cout << std::setw(10) << std::right << dataFile.m_timeUnit << "  " << std::setw(15) << std::right << dataFile.m_valueUnit << std::endl;
	IBK::Unit seconds("s");
	IBK::Unit ioTimeUnit( IBK::Unit(dataFile.m_timeUnit) );
	for (unsigned int i=0; i<dataFile.m_timepoints.size(); ++i) {
		// time points are always in seconds, need to convert to IO unit
		double tp = dataFile.m_timepoints[i];
		IBK::UnitList::instance().convert(seconds, ioTimeUnit, tp);
		// access data for this time point
		const double * values = dataFile.data(i);
		std::cout << std::setw(10) << std::right << tp << "  " << std::setw(15) << std::right << values[0] << std::endl;
	}
	std::cout << std::endl;

	// write copy of file
	dataFile.m_filename = filename.withoutExtension() + "-copy.d6o"; // set filename
	notify.m_process = "Writing... ";
	// The filename must be set in the member variable of the project
	dataFile.write(&notify);
	std::cout << std::endl;
}



void createDataIO() {
	std::vector<unsigned int> element_numbers;

	DATAIO::DataIO d;
	// specify start year, needed to map simulation/output time offsets to actual date/time stamps
	d.m_startYear = 2000;
	// set the file data type
	d.m_type = DATAIO::DataIO::T_FIELD; // used for the keyword ELEMENTS or SIDES and in the header
	// store project file name (optional)
	d.m_projectFileName = "some_project.d6p";
	// store geometry file and hash of the geometry file content
	d.m_geoFileName = "some_project_54293221.g6o";
	d.m_geoFileHash = 1293211332;
	// store quantity information
	d.m_quantity = "Thermodynamic Temperature";
	d.m_quantityKeyword = "Temperature";
	// store data and time format
	d.m_spaceType = DATAIO::DataIO::ST_SINGLE;
	d.m_timeType  = DATAIO::DataIO::TT_NONE;
	// store IO units
	d.m_timeUnit  = "h";
	d.m_valueUnit = "C";
	// store number of values and element numbers (or side numbers, if writing fluxes)
	d.m_nums = element_numbers; // element_numbers holds as many unique element numbers as values stored per time index
	// finally write the file header
	d.writeHeader();
}



void createGeoFile() {
	std::vector<int> materials;
	std::vector<int> elements;
	std::vector<int> sides;
	bool use_binary_format = true;

	// create new DATAIO::GeoFile instance
	DATAIO::GeoFile geofile;

	// *** Populate data tables ***

	// compose material data table (the vector materials is from your code)
	for (unsigned int i=0; i<materials.size(); ++i) {
		// GeoFile::Material is a class holding all information of a single material definition
		DATAIO::GeoFile::Material mat;
		mat.name  = "some name"; // some descriptive name
		mat.color = IBK::Color::fromHtml("#121212"); // some color, see IBK::Color
		mat.ID    = i; // unique material ID, referenced in elements table below
		// add material definition to list of materials in geofile
		geofile.m_matDefs.push_back(mat);
	}

	// compose element data table (the vector elements is from your code)
	std::vector<double> xWidths;
	for (unsigned int i=0; i<elements.size(); ++i) {
		// GeoFile::Element holds all element-specific information
		DATAIO::GeoFile::Element el;
		// specify material ID, this ID should be one of the IDs given to materials in
		// the geofile.m_matDefs vector.
		el.matnr = 0;
		// specify unique element number
		el.n = i;
		// specify grid coordinates (3D grid, coordinate system starting left-bottom-back)
		el.i = i;
		el.j = 0;
		el.k = 0;
		// specify element center coordinates (typically in [m], 3D grid, coordinate system
		// starting left-bottom-back)
		el.x = 0.005 + i*0.01;
		el.y = 0.5;
		el.z = 0.5;
		// append element width to vector (for later use)
		xWidths.push_back(0.01);
		// add element information to vector with elements
		geofile.m_elementsVec.push_back(el);
	}

	// compose sides data table (vector sides is from your code)
	for (unsigned int i=0; i<sides.size(); ++i) {
		// GeoFile::Side holds all side-specific information
		DATAIO::GeoFile::Side sid;
		// specify unique side number
		sid.n = i;
		// specify side orientation
		sid.orientation = DATAIO::GeoFile::X_DIRECTION;
		// specify grid line coordinates (see above)
		sid.i = i;
		sid.j = 0;
		sid.k = 0;
		// specify grid line center coordinates (typically in [m], see above)
		sid.x = i*0.01;
		sid.y = 0.5;
		sid.z = 0.5;
		// add side information to vector with sides
		geofile.m_sidesVec.push_back(sid);
	}

	// compose grid data, basically all column, row, stack widths
	geofile.m_grid.xwidths.swap(xWidths);
	geofile.m_grid.ywidths.push_back(1);
	geofile.m_grid.zwidths.push_back(1);

	// *** Compose file name according to naming convention ***

	// Set the string projectContent to some relevant data describing the simulation project,
	// at least material references, grid options, everything that determines the content of
	// the geometry file.
	std::string projectContent  = "input file content or some unique ASCII "
								  "representation of input data that matches this grid";

	// compute project file hash code, include IBK_crypt.h for function SuperFastHash().
	unsigned int projectFileHashCode = IBK::SuperFastHash(projectContent);
	std::string projectFileHash = IBK::val2string<unsigned int>(projectFileHashCode);

	IBK::Path projectFilePath("some_project.d6p");
	IBK::Path resultsPath("some_project/results");
	// projectFilePath and resultsPath (from your code) hold the filename
	// of the project file without path and the target directory for the geometry
	// file, respectively.

	IBK::Path geoFilePath = resultsPath / (projectFilePath.withoutExtension() + "_" + projectFileHash);

	// append extension based on binary/ASCII format
	if (use_binary_format)		geoFilePath.addExtension("g6b");
	else						geoFilePath.addExtension("g6a");

	// *** write geometry file ***
	try {
		geofile.m_filename = geoFilePath; // set new geometry filename
		geofile.m_isBinary = use_binary_format; // determines binary format writing
		geofile.write();
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}

}




/*! \file main.cpp
	\brief This simple example application illustrates reading and writing of DataIO containers.
*/
