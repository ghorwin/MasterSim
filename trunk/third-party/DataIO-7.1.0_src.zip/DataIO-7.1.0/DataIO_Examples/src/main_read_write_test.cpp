#include <iostream>
#include <string>
#include <cstdlib>

#include <IBK_Exception.h>
#include <IBK_StopWatch.h>
#include <IBK_UnitList.h>
#include <IBK_crypt.h>
#include <IBK_StringUtils.h>

// include central header file for DataIO library.
#include <DataIO>

int main(int argc, char * argv[]) {
	(void)argc;(void)argv;

	const unsigned int NUM_FILES = 5;
	const char * dataFiles[NUM_FILES] = {
		"D5_2D_ASCII.out",
		"D5_4D_ASCII.out",
		"D5_4D_bin.out",
		"D6_4D_ASCII.d6o",
		"stats.d6o"
	};

	for (unsigned int i=0; i<NUM_FILES; ++i) {
		try {
			IBK::Path filePath(dataFiles[i]);
			std::cout << "\n*** " << filePath.str() << " ***" << std::endl;
			filePath = IBK::Path("../../data/files") / filePath;
			DATAIO::listDataIOHeader(filePath);
		}
		catch (IBK::Exception & ex) {
			ex.writeMsgStackToError();
		}
	}

	for (unsigned int i=0; i<NUM_FILES; ++i) {
		try {
			DATAIO::DataIO d;
			IBK::Path filePath(dataFiles[i]);
			filePath = IBK::Path("../../data/files") / filePath;
			DATAIO::TextNotificationHandler notify;
			notify.m_process = std::string(dataFiles[i]) + " ";
			d.read(filePath, false, &notify);
			std::cout << std::endl;
			if (d.m_geoFileName.isValid()) {
				DATAIO::GeoFile g;
				IBK::Path geoFilePath = filePath.parentPath() / d.m_geoFileName;
				notify.m_process = d.m_geoFileName.str() + " ";
				g.read(geoFilePath, &notify);
				std::cout << std::endl;
			}
		}
		catch (IBK::Exception & ex) {
			ex.writeMsgStackToError();
		}
	}

	return EXIT_SUCCESS;
}

/*! \file main_read_write_test.cpp
	\brief This simple example application illustrates reading and writing of DataIO containers.
*/
