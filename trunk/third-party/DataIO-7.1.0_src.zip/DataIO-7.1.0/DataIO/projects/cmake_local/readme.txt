This version of CMakeLists.txt is needed for whole project builds. 

DO NOT DELETE!

