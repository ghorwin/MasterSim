// Example for the use of the IBK Library class 'ptr_list'.
#include <iostream>
#include <cstdlib> // for EXIT_SUCCESS
#include <IBK_ptr_list.h>
using namespace std;
using IBK::ptr_list;

// Parent class for testing the ptr_list.
class Base {
  public:
	Base() : baseNum(++baseCount)
		{ cout << "Base " << baseNum << " constructed" << endl; }
	virtual ~Base()
		{ cout << "Base " << baseNum << " destructed" << endl; }
	int baseNum;
	static int baseCount;
};

// Derived class for testing the ptr_list.
class Derived : public Base {
  public:
	Derived() : Base(), derivedNum(++derivedCount)
		{ cout << "Derived " << derivedNum << " constructed" << endl; }
	virtual ~Derived()
		{ cout << "Derived " << derivedNum << " destructed" << endl; }
	int derivedNum;
	static int derivedCount;
};

int Base::baseCount = 0;
int Derived::derivedCount = 0;

// ===========================================================================

int main() {
	// ptr_list is designed to hold pointers to dynamically allocated objects, and thus
	// it is possible to use polymorphism by creating a list of base class pointers:

	// at first create a ptr_list for pointers to objects of type Base or Derived
	ptr_list<Base> baseList;

	cout << "Creating objects and adding pointers to list" << endl;
	baseList.add(new Base);
	baseList.add(new Derived);
	baseList.add(new Derived);
	baseList.add(new Base);
	baseList.add(new Derived);

	cout << "\nAccess to elements via index" << endl;
	Base* b = baseList[2];
	cout << "  Numbers of 3rd element:  Base=" << b->baseNum;
	Derived* d = dynamic_cast<Derived*>(b);
	if (d!=NULL)  cout << " Derived=" << d->derivedNum << endl;
	else          cout << endl;

	cout << "\nRemoving third element" << endl;
	ptr_list<Base>::iterator it = baseList.begin();
	advance(it, 2);      // now it points to the third element
	// now destruct object, release memory and remove pointer from list
	baseList.remove(it);

	cout << "\nEnd of scope, the ptr_list releases objects and memory when destructed" << endl;
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

