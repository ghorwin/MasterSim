#include <iostream>
#include <string>
#include <map>


#include <IBK_FileReader.h>
#include <IBK_Exception.h>

int main() {

	const int TESTCASE = 1;

	if( TESTCASE == 1) {
		IBK::Path filenameOK("Benchmark1MaterialA.m6");

		bool output = false;

		if( output) {
			std::ofstream out(filenameOK.str().c_str());
			for( unsigned int i=0; i<5000; ++i) {
				for( unsigned int j=0; j<2000; ++j)
					out << i << ":" << j << "  ";
				out << "\n";
			}
		}
		else {
			IBK::Path filenameBad("Missing.txt");
			std::ofstream fout("FileReaderResult.txt");
			std::ofstream resout("FileReaderCheck.txt");

			IBK::FileReader readerBad(filenameBad);

			try {
				readerBad.readFirst();
				fout << "First line of file: " << readerBad.filename() << "\n";
				fout << readerBad.lines().front();
			}
			catch(IBK::Exception& ex) {
				fout << "Error while reading file: " << readerBad.filename() << "\n";
				fout << "Message: " << ex.what() << "\n";
			}

			IBK::FileReader readerGood(filenameOK);

			fout << "\nNext try.\n\n";

			unsigned int counter = 1;
			try {
				IBK::FileReader::ReadState res = readerGood.readFirst();
				if( res == IBK::FileReader::FR_Eof)
					fout << "End of file " << readerGood.filename() << " reached" << "\n";
				else {
					fout << "First line of file: " << readerGood.filename() << "\n";
					const std::vector<std::string>& lines = readerGood.lines();
					for( std::vector<std::string>::const_iterator it=lines.begin(); it!=lines.end(); ++it)
						resout << *it << "\n";

					do {
						readerGood.clearBuffer();
						++counter;
						res = readerGood.readNext(1);
						const std::vector<std::string>& lines = readerGood.lines();
						for( std::vector<std::string>::const_iterator it=lines.begin(); it!=lines.end(); ++it)
							resout << *it << "\n";
					} while(res == IBK::FileReader::FR_Good);

					fout << "\nEnd of file\n";
				}
			}
			catch(IBK::Exception& ex) {
				fout << "Error while reading file: " << readerGood.filename() << "\n";
				fout << "Message: " << ex.what() << "\n";
			}
		}
	}
	else if( TESTCASE == 2){
		IBK::Path filenameOK("small.txt");

		std::ofstream fout("FileReaderResult.txt");
		std::ofstream resout("FileReaderCheck.txt");


		fout << "\nRead small file.\n\n";
		std::vector<std::string> lines;
		std::vector<std::string> lastLineTokens;
		std::string errmsg;

		try {
			long long res = IBK::FileReader::readAll(filenameOK, lines, lastLineTokens);
			fout << "Result is " << res << "\n\n";
		}
		catch(IBK::Exception& ex) {
			fout << "Error while reading file: " << filenameOK << "\n";
			fout << "Message: " << ex.what() << "\n";
		}

		for( std::vector<std::string>::iterator it=lines.begin(); it!=lines.end(); ++it)
			resout << *it << "\n";

	}

	return 0;
}
