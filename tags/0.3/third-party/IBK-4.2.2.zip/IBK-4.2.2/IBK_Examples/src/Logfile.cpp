// Example for the class IBK::Logfile.
#include <IBK_Logfile.h>
#include <iostream>
#include <cstdlib> // for EXIT_SUCCESS
using namespace std;
using IBK::Logfile;

void do_something();

int main() {
	// output to the default console streams
	cerr << "This is an error message (printed to console)!" << endl;
	clog << "This is a log message (printed to console)!" << endl;

	// With the class IBK::Logfile we can redirect these outputs to files
	// ios_base::app lets us append to previus outputs and from now on all
	// outputs to cerr are redirected to the file 'my_errors.log'
	Logfile errorlog(cerr, "my_errors.log", ios_base::app);
	(void)errorlog; // add this to remove "unused variable" warning in compiler

	cerr << "\nStarting new error log (written to my_errors.log):" << endl;

	do_something();
	// when leaving the scope, the stream redirection will be resetted

	clog << "Progress 3 (printed to console)" << endl; // so, this appears on the screan again

	// listing contents of log files
	cout << "...my_errors.log..." << endl;
	std::ifstream in("my_errors.log");
	cout << in.rdbuf() << endl;

	cout << "...progress.log..." << endl;
	std::ifstream in2("progress.log");
	cout << in2.rdbuf() << endl;

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}


void do_something() {
	cerr << "ok, here might be an error" << endl;
	// we can create another logfile here
	Logfile progresslog(clog, "progress.log");
	clog << "Progress 1  (written to progress.log)" << endl;  // this appears in the logfile
	clog << "Progress 2  (written to progress.log)" << endl;
} // progresslog goes out of scope and stream is redirected back to console

