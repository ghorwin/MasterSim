// Example for the use of the IBK Library classes Unit and UnitListManager.
#include <memory>
#include <iostream>
#include <iterator>
#include <cstdlib> // for EXIT_SUCCESS
#include <IBK_UnitList.h>
#include <IBK_Unit.h>
using namespace std;
using IBK::Unit;
using IBK::UnitList;

int main() {
	// *** Initialisation of the unit list ***
	try {
		// create a simple units by name
		Unit u1("mm");
		Unit u2("s");

		// retrieve the base unit and create a new unit with it
		Unit u3( u1.base_id() );

		// assign a Unit data type to another
		u1 = u3;

		// convert a value from one unit to another
		cout << "Enter a value followed by a unit: ";
		double val;
		cin >> val >> u1;
		if (!cin)  throw runtime_error("Invalid input!");
		// print a list of available units for conversion
		vector<Unit> units;
		if (UnitList::instance().convertible_units(units, u1, true)) {
			cout << "Available units for conversion are: ";
			copy(units.begin(), units.end(), ostream_iterator<Unit>(cout, " ") );
		};

		cout << "\nEnter the unit to convert the value to: ";
		cin >> u2;
		UnitList::instance().convert(u1, u2, val);
		cout << "The result is: " << val << " " << u2 << endl;
	}
	catch (std::exception& ex) {
		cerr << ex.what() << endl;
	}
#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}
