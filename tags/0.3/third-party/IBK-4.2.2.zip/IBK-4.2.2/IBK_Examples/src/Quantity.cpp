#include <iostream>
#include <string>
#include <vector>

#include <IBK_QuantityManager.h>
#include <IBK_Exception.h>

using namespace std;
using namespace IBK;

int main() {
	try {
		// define quantities (can be done in a text file, descriptions are optional)
		std::string quantities =
			"STATE Moisture mass density [kg/m3] 'Total mass of liquid water and water vapor'\n"
			"STATE Temperature           [C]     'Some temperature'\n"
			"STATE Pressure              [Pa]\n"
			"FLUX HeatFluxDensity        [W/m2]\n";
		// populate quantity manager with quantities
		QuantityManager quantMan;
		quantMan.read(quantities);

		// retrieve global indices for quantities known by name
		unsigned int idx = quantMan.index("Temperature");
		// glob_temp_idx -> 1
		std::cout << "Quantity 'Temperature' has index " << idx << std::endl;
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}
	return 0;
}
