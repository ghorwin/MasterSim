#include <IBK_cuboid.h>
#include <IBK_point.h>

using namespace std;

int main() {
	// define a cuboid by point coordinates
	IBK::point3D<int> p1(1,2,1);
	IBK::point3D<int> p2(5,3,10);
	// define a cuboid
	IBK::cuboid<int> cube(p1.m_x, p1.m_y, p2.m_x, p2.m_y, p1.m_z, p2.m_z);
	// calculate width, height and depth
	int width = cube.width();
	int height = cube.height();
	int depth = cube.depth();
	// cube output
	std::cout << "Cube: " << std::endl;
	std::cout << cube.formattedString() << std::endl;
	std::cout << "has the dimendions (" << width << "," << height << "," << depth << ")" << std::endl;
	
	// project to xy-plane
	IBK::rectangle<int> cube_xy = cube.XY();
	// calculate width and height
	width = cube_xy.width();
	height = cube_xy.height();
	// rectangle output
	std::cout << std::endl << "Projection to xy-plane: " << std::endl;
	std::cout << cube_xy.formattedString() << std::endl;
	std::cout << "has the dimendions (" << width << "," << height << ")" << std::endl;

	// project to xz-plane
	IBK::rectangle<int> cube_xz = cube.XZ();
	// calculate width and height
	width = cube_xz.width();
	height = cube_xz.height();
	// rectangle output
	std::cout << std::endl << "Projection to xz-plane: " << std::endl;
	std::cout << cube_xz.formattedString() << std::endl;
	std::cout << "has the dimendions (" << width << "," << height << ")" << std::endl;

	// project to xz-plane
	IBK::rectangle<int> cube_yz = cube.YZ();
	// calculate width and height
	width = cube_yz.width();
	height = cube_yz.height();
	// rectangle output
	std::cout << std::endl << "Projection to yz-plane: " << std::endl;
	std::cout << cube_yz.formattedString() << std::endl;
	std::cout << "has the dimendions (" << width << "," << height << ")" << std::endl;

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

