#include <iostream>
#include <vector>
#include <cstdlib> // for EXIT_SUCCESS and EXIT_FAILURE
using namespace std;

#include <IBK_assert.h>
using namespace IBK;

void do_something(const std::vector<double>& vec);
double get_value(const std::vector<double>& vec, unsigned int j);

int main() {
	try {
		vector<double> vec(8);
		//get_value(vec, 8);	// would fail because of wrong index
		do_something(vec);		// somewhere in this function hierarchy a check will fail
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}

	// other forms of IBK_ASSERT
	try {
		double b = 15;
		// message string is printed "as is"
		IBK_ASSERT_X(12*6 == b, "Value was: " << b);
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}
	try {
		double b = 15;
		// message string is evaluated and piped into stream, hence you can use stream operators to compose
		// complex message strings
		IBK_ASSERT_XX(12*6 == b, "Value was: " << b);
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}
	try {
		IBK_STATIC_ASSERT(sizeof(unsigned int) == 4);
		// uncommenting the following line gives a error at compile time
		// IBK_STATIC_ASSERT(sizeof(long int) == 7);
	}
	catch (IBK::Exception & ex) {
		ex.writeMsgStackToError();
	}


#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

double get_value(const std::vector<double>& vec, unsigned int i) {
	IBK_ASSERT(i < vec.size());	// ensure i is in the allowed range
	return vec[i];
}

void do_something(const std::vector<double>& vec) {
	// typical index error here
	for (unsigned int i=0; i<=8; ++i) {
		cout << i << "  " << get_value(vec, i) << endl;
	}
}

