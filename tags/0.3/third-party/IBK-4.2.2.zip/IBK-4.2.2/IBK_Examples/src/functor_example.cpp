// Example for some IBK functors
#include <IBK_math.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <cstdlib> // for EXIT_SUCCESS
using namespace std;

int main() {
	const double data[8] = { -2, -5, 1, 15, -2, 5, -.5, .4 };
	std::vector<double> c1(data, data + sizeof(data)/sizeof(double) );

	// we can use the IBK::abs() unary function to transform the range
	// so that all values are positive
	std::transform(c1.begin(), c1.end(), c1.begin(), IBK::abs<double>());
	// NOTE: the std::abs() function is only declared for integers, so the
	//       result would be wrong since all doubles would have been
	//       converted to integers and back to doubles
	std::copy(c1.begin(), c1.end(), ostream_iterator<double>(cout, "  ") );
	cout << endl;

#ifdef __WIN32__
	system("pause");
#endif
	return EXIT_SUCCESS;
}

