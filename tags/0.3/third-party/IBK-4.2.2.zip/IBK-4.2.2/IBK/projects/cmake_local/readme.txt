This version of CMakeLists.txt is needed for whole project builds, as for example
in Delphin 5.7 and 5.8. 

DO NOT DELETE!

