// IBK Library - Collection of classes, functions and algorithms
//               for development of numeric simulations
//
// Copyright (C) 2007 Andreas Nicolai, Andreas.Nicolai@gmx.net
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

#ifndef IBK_hardwareH
#define IBK_hardwareH

#include <windows.h>
#include <string>
#include <vector>

namespace IBK {

#pragma pack(push, 1)
struct sCpuId
{
    unsigned int ulVersion;
    unsigned int ulOther;
    unsigned int ulExtendedFeatures;
    unsigned int ulFeatures;
};
#pragma pack(pop)

std::vector<std::string> getMacAddress();

sCpuId getCPUId();
#ifdef __BORLANDC__
std::string getCPUString();
#else
#endif

} // namespace IBK

#endif // IBK_hardwareH

